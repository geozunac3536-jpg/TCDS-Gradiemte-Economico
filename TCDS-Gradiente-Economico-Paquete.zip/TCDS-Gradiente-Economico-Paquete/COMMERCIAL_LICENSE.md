# Licencia Comercial TCDS
Este repositorio ofrece una **licencia abierta** (CC BY-NC-SA) para uso no comercial.
Para uso **comercial**, contacta a: geozunac3536@gmail.com

Condiciones base sugeridas:
- Reconocimiento de autoría.
- Regalía por uso de contenidos, protocolos, marcas y librerías derivadas.
- Auditoría a solicitud del autor.
